всем привет. добро пожаловать в мой крутой тренажёр азбуки морзе!
запуск программы
если у вас на компьютер установлен bgt, то открывайте morser.bgt.
если же bgt у вас нет, запустите morser.bat.

чтобы проиграть какой-нибудь текст морзянкой, в окне программы нажмите правый шифт. он по английски спросит, что вы хотите перевести. русские буквы поддерживаются
когда вы напечатали, нажмите энтер. программа проиграет сообщение морзянкой.
чтобы проиграть текстовый файл морзянкой, нажмите правый контрол. программа попросит ввести имя файла, после чего программа начнёт пропикивать файл морзянкой
для сохранения толькочто проморзенного текста, нажмите левый шифт+энтер.
чтобы проиграть последнюю морзянку, нажмите энтер.
если вы будете нажимать на буквы на клавиатуре, программа будет пропикивать их азбукой морзе. при этом не нужно ждать, пока программа допикает букву. можно просто нажимать на буквы, а программа их аккуратно будет морзить в нужный момент. можно написать слово и подождать, пока оно допикает, затем следующее слово...
вы ещё можете передавать азбуку морзе, нажимая на клавишу пробела, как на морзе ключе. при этом буквы, которые у вас получились, будут отображены на дисплее брайля.
чтобы включить или выключить произнесение получившихся букв, нажмите клавишу таб.
чтобы сменить скорость морзянки, удерживайте клавишу стрелки вправо или влево. когда отпустите, прозвучит тестовый сэмпл на выбранной вами скорости.
чтобы сменить высоту звука, удерживайте вертикальные стрелки.
чтобы включить звук ДКМ, нажмите ф11.
чтобы включить или выключить все звуки программы, нажмите Ф12. полезно, когда вы хотите работать беззвучно или только с брайлевским дисплеем.
в программе есть 3 режима морзянки.
1: синтезированный сигнал
2: крутой телеграфный звук, работает только в автоматическом и полуавтоматическом режиме.
и 3- это морзянка брайлевским дисплеем. то есть на дисплее отображается полоска вместо звуков морзянки так, что вы её можете ощутить рукой.
чтобы записать морзянку в ручном режиме, то есть записать, как вы передаёте клавишей пробела, нажмите Ф2. программа пикнет. начинайте передавать.
когда вы закончите, нажмите энтер. ваша запись будет проиграна.
после прослушивания нажмите энтер, чтобы сохранить в wav файл, или эскейп для отмены.
чтобы сменить язык букв для упражнений, нажмите контрол пробел. доступен русский и английский.
чтобы потренироваться в приёме морзянки, нажмите ф3. у вас программа спросит, сколько букв вы хотите распознавать за группу. новечкам лучше выбрать 1.
после этого программа начнёт пикать случайные буквы, а вы должны угадать и написать результат на клавиатуре.
внимание, раскладка клавиатуры должна совпадать с языком, который вы по контрол пробелу выбрали.
по истечении минуты, вам компьютер напишит, сколько букв вы правильно приняли, а сколько - не правильно. нажмите пробел или энтер, чтобы выйти из диалога.
чтобы потренироваться в передаче морзянкой, для начала выберите свою скорость с помощью стрелок или калибровки по клавише ф7, см. раздел калибровка. выберите язык: контрол пробел, затем жмите Ф4.
у вас спросит, сколько букв в группу вы хотите передавать. напишите число.
затем nvda отсчитает: 5, 4, 3, 2, 1. компьютер даст группу из случайных русских или английских букв, в зависимости от выбранного вами языка, и вы должны передать эти буквы на морзе ключе клавишей пробела.
программа скажет, какую букву вы реально передали после каждой переданной вами буквы. когда группа закончится, компьютер скажет: next. и даст ещё группу.
по истечении минуты вы не сможете передавать пробелом, а nvda будет приговаривать: press enter to get info.
нажмите энтер, и откроется диалог, где компьютер скажет ваш результат.
морзе блокнот
морзе блокнот- это обычный записыватель текстовых заметок в txt-подобные файлы. только вместо того, чтобы печатать на клавиатуре, вы передаёте на ключе морзе.

перед тем, как открыть блокнот, рекомендуется выбрать ту скорость, с какой вам удобно передавать, стрелками влево вправо.
чтобы открыть блокнот, нажмите f5. nvda скажет notepad.
просто начинайте передавать морзянку клавишей пробела. можно менять раскладку контрол пробелом, чтобы программа понимала морзянку на другом языке.
чтобы скопировать весь текст, нажмите ctrl c.
чтобы редактировать текст в текстовом редакторе с обычной клавиатуры, нажмите ctrl+e
чтобы сохранить переданный текст как текстовый файл, нажмите ctrl s и введите имя файла с расширением.
чтобы сохранить текст ввиде точек и тире, нажмите контрол шифт s и введите имя файла.

морзе напоминалка.
если вы хотите поставить морзе напоминалку, нажмите ф6.
вас сначала спросит, на какое время поставить. напишите в таком формате: час двоеточие минута двоеточие секунда, без пробелов. не пишите 00 или 05, пишите без нуля в начале.
вместо времени можно написать: /telltime
тогда морзе программа может вам о чём-то напоминать каждый час.
потом вас спросит, о чём напомнить. напишите, например: щас начнётся конференция. нажмите энтер и не закрывайте программу.
скорость и звук морзянки, который вы выбрали в главном меню, будет использован в напоминалке.
ещё один способ поставить напоминалку, это прописать его в файле procs.txt
синтаксис такой. каждое напоминание в каждой строке. одна строка выглядит так:
time=text
где тайм- это время или /telltime, а текст- это любой текст с пробелами. в тексте нельзя использовать знак равно. выдаст ошибку.
можно даже сделать так:
/telltime=hello, привет! начался новый текст
или так:
/telltime=текущее время /time
или так
12:30:0=текущее время /time, конференция начинается.
calibrating your morsing speed (very early beta)
to calibrate your speed, press f7.
computer will say: start morsing.
you must morse some real words or numbers. it will not check your morsed letters, but it will check the length of dots. after 50 dots, it will play some morse sample, and calibration will be finished.

setting a stream of morse to another output device
the output device number is stored in the configuration parameter /output.
/output=def meens that you use the default output device. set /output to def if you want to set it to default.
you would ask, how to know what number is which output device? and i would answer:
open interpreter folder, and open the selectdevice.bat or selectdevice.bgt.
an alert box with all output device numbers will appear. for example
speakers realtech high definition audio is number 0, line 1 virtual audio cable is number 1.
then, when you press ok, a notepad with the config file will appear.
find /output, and after the equals (=) sign, type the number of the needed output device.
save it, and close with alt f4.
another way to change the output device for just one session of the morser program.
in the folder of the morse program create an empty folder with the name: stream
then launch great morser. it will detect the folder, delete it and ask you to open an output device. choose it with up and down arrows. press enter to open.

configuration file
to change the configuration, go to interpreter folder, then start dictserializer.bat or dictserializer.bgt, depends if you have bgt installed or not, see very beginning of readme.
 you will be took to a notepad window.
/russian is the russian alphabet. needed for layouts
/english is the english alphabet.
/numbers are numbers from 1 to 0
/punct is punctuations. dot, comma, question and exclamation mark
/replace=letters to replace. for example russian alphabet has a some letters that translated equally into morsecode.
/braille is the braille sign to pop up on a braille display. it is used to recognize morse code with your fingers without beeping. for example you can write:
/braille=----------
then a line will pop up on a braille display. and each time a new dot or dash is transmeted, a line will pop up.
after all /commands, letters and numbers are assigned. don't change them. if you need, you can change only dots and dashes of each letter, but don't delete or modify the position of the letters.
after you finished with the config file, simply save it. when saved, the dictserializer will encode your config file. just close notepad with alt f4.
morse commands
when the morse program translates some text to morse, it looks for the folowing commands:
/time, morses the time. for example, you can write; the time is /time. and it will morse the time instead of /time


that meens that this commands work everywhere.

to do list
playing .morse files with dots and dashes.
creating .morse files. sending them to server: not decided.
supporting arduino morse keys: not decided.
contacting me by sending morse messages by email. haha
keying speed detection system, partially integrated.
q-code exercise: not decided.
sending messages to a morse tranceaver via arduino: hardwere needed, not decided.
and finally, translating the interface to russian! maybe not finaly, but i don't know when.